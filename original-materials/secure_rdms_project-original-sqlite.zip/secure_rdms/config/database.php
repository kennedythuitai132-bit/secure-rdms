<?php
// SQLite database bootstrap. Requires PHP PDO_SQLite extension.
$base = dirname(__DIR__);
if (!is_dir($base . '/storage')) mkdir($base . '/storage', 0700, true);
$pdo = new PDO('sqlite:' . $base . '/storage/rdms.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$pdo->exec('PRAGMA foreign_keys = ON');
$schema = [
"CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, full_name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','researcher','viewer')), is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP, last_login TEXT)",
"CREATE TABLE IF NOT EXISTS research_data (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT, filename TEXT NOT NULL, original_filename TEXT NOT NULL, file_path TEXT NOT NULL, file_size INTEGER, mime_type TEXT, uploaded_by INTEGER NOT NULL, project_code TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(uploaded_by) REFERENCES users(id))",
"CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT, action TEXT NOT NULL, details TEXT, ip_address TEXT, user_agent TEXT, status TEXT DEFAULT 'success', created_at TEXT DEFAULT CURRENT_TIMESTAMP)",
"CREATE TABLE IF NOT EXISTS mfa_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, code_hash TEXT NOT NULL, expires_at TEXT NOT NULL, used INTEGER DEFAULT 0, FOREIGN KEY(user_id) REFERENCES users(id))",
"CREATE TABLE IF NOT EXISTS security_alerts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, alert_type TEXT NOT NULL, message TEXT NOT NULL, severity TEXT DEFAULT 'medium', resolved INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id))",
"CREATE TABLE IF NOT EXISTS login_attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, attempted_at TEXT DEFAULT CURRENT_TIMESTAMP, success INTEGER DEFAULT 0)"
];
foreach ($schema as $sql) $pdo->exec($sql);
$count = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
if (!$count) {
  $seed = $pdo->prepare('INSERT INTO users(username,email,password_hash,full_name,role) VALUES(?,?,?,?,?)');
  foreach ([['admin','admin@example.test','Admin@123','System Administrator','admin'],['researcher1','researcher@example.test','Researcher@123','Researcher One','researcher'],['viewer1','viewer@example.test','Viewer@123','Viewer One','viewer']] as $u) $seed->execute([$u[0],$u[1],password_hash($u[2], PASSWORD_DEFAULT),$u[3],$u[4]]);
}
