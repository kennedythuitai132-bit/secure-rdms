# Secure Research Data Management System (RDMS)

A PHP web application for a university research repository, with password authentication, a time-limited demo MFA code, role-based access, encrypted file storage, audit logs, security alerts and summary reports.

## Run without XAMPP

1. Install **PHP 8.1 or newer**. Make sure these PHP extensions are enabled: `pdo_sqlite`, `sqlite3`, and `openssl`. XAMPP is not required.
2. Open a terminal in this `secure_rdms` folder.
3. Start the PHP built-in server:
   - Windows PowerShell: `php -S 127.0.0.1:8000`
   - macOS/Linux: `php -S 127.0.0.1:8000`
4. Open `http://127.0.0.1:8000` in your browser.
5. Sign in using one of the accounts below. After the password is accepted, enter the demo OTP shown on the MFA page.

## Demo accounts

| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `Admin@123` |
| Researcher | `researcher1` | `Researcher@123` |
| Viewer | `viewer1` | `Viewer@123` |

These credentials are for local demonstration only. Change them before any shared or production deployment.

## Project layout

- `index.php` — redirects to login/dashboard
- `login.php`, `logout.php` — password + MFA demo flow and sign-out
- `dashboard.php` — role-aware dashboard
- `files.php` — upload, encrypt, list and decrypt/download research files
- `audit.php` — administrator audit log with filters
- `alerts.php` — review and resolve security alerts
- `reports.php` — security metrics and activity summaries
- `users.php` — create users, assign roles and activate/deactivate accounts
- `config/database.php` — SQLite schema and demo seed accounts
- `includes/functions.php` — sessions, CSRF, RBAC, encryption and audit helpers
- `assets/css/style.css` — frontend styling
- `uploads/` — encrypted `.enc` files
- `storage/` — generated SQLite database

## Important limitations and security notes

- The app creates its database on first request. If PHP reports `could not find driver`, enable/install the `pdo_sqlite` extension for the PHP installation used by the command `php`.
- The OTP is displayed on screen only for demonstration; it is not sent by email/SMS.
- The encryption key fallback is a local-demo key. Set the `RDMS_ENCRYPTION_KEY` environment variable to a long random secret before testing with non-demo data. For real deployment, use a managed key service and authenticated encryption (for example AES-GCM), HTTPS, backups, rate limiting, secure session cookies, stricter file validation and independent security review.
- This is an academic demonstrator, not a production-ready service. Audit logs are useful records but are not tamper-proof against a server administrator.
- PHP's built-in server is intended for local development/demo use, not internet-facing production hosting.
